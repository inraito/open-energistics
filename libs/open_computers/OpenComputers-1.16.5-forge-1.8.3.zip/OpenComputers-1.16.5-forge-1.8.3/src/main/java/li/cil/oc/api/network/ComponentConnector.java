package li.cil.oc.api.network;

/**
 * For nodes that are both component and connector.
 */
public interface ComponentConnector extends Component, Connector {
}
