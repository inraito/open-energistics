/**
 * This package contains interfaces to be implemented on components.
 * <br>
 * This will allow OpenComputers to provide some more advanced integration
 * with your components.
 */
package li.cil.oc.api.component;

import li.cil.oc.api.API;