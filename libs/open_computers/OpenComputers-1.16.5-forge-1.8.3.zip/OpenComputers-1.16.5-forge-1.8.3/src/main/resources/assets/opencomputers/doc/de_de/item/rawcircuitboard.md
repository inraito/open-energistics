# Leiterplattenrohling

![Nicht Sushi.](oredict:opencomputers:materialCircuitBoardRaw)

Zwischenprodukt beim Fertigen. Wird verwendet, um [Leiterplatten](circuitBoard.md) (oder [gedruckte Leiterplatten](printedCircuitBoard.md), je nach dem welches Recipe-Set verwendet wird) zu fertigen.
