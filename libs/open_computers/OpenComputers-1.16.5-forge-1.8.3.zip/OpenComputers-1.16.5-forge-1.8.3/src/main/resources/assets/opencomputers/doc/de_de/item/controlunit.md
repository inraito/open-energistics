# Kontrolleinheit

![Mit eingebauter Cruising-Funktion.](oredict:opencomputers:materialCU)

Hochstufiges Craftingitem in weiter entwickelten Schaltkreisen wie [CPUs](cpu1.md).
