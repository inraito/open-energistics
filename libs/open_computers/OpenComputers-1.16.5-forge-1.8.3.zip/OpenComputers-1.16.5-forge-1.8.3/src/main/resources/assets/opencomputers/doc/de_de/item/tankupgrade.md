# Tank Upgrade

![Suck it.](oredict:opencomputers:tankUpgrade)

Das Tank-Upgrade ermöglicht es Geräten, Flüssigkeiten zu halten. Jeder Tank kann nur eine einzige Art von Flüssigkeit halten und stellt ein Volumen von 16 Eimern (16.000mB) zur Verfügung. [Roboter](../block/robot.md) und [Drohnen] können Flüssigkeiten aus der Welt aufnehmen und die Flüssigkeit dann in Tanks oder, wenn die Flüssigkeit das ermöglicht, wieder in der Welt platzieren. Es gibt kein Maximum an installierten Tanks in einem Gerät.
