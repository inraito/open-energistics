# Abstrakter-Bus-Karte

![Mehr Netzwerktechnik!](oredict:opencomputers:abstractBusCard)

Diese Karte erlaubt es [Computern](../general/computer.md), [Servern](server1.md) und [Robotern](../block/robot.md) mit Abstract Busses von StargateTech2 zu interagieren. Wenn die Karte installiert ist, werden sich die entsprechenden Blöcke mit dem abstrakten Bus verbinden und eine Komponente wird für die Maschine sichtbar. Damit können Nachrichten über den Bus gesendet werden. Hereinkommende Nachrichten werden in Signale konvertiert und zur Maschine gesendet.
