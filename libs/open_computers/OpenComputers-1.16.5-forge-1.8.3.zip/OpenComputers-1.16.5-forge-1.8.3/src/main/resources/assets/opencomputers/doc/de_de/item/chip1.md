# Microchips

![Nicht essbar.](oredict:opencomputers:circuitChip1)

Microchips sind die Grundlage für das Bauen von elektronischen Komponenten. Sie kommen in verschiedenen Stufen und ermöglichen unterschiedliche Komponentenstufen.
