# Schneidedraht

![Kein Würgedraht. Wirklich.](oredict:opencomputers:materialCuttingWire)

Dieses Item wird nur im Hard-Mode-Rezept für [Leiterplattenrohlinge](rawCircuitBoard.md) verwendet. Ineffektiv.
