# Printed Circuit Board

![AKA PCB](oredict:opencomputers:materialCircuitBoardPrinted)

The printed circuit board is, next to the [transistor](transistor.md), one of the most basic crafting materials in OpenComputers. It is used as a basis for many components, such as [cards](card.md) and a large number of [blocks](../block/index.md).
