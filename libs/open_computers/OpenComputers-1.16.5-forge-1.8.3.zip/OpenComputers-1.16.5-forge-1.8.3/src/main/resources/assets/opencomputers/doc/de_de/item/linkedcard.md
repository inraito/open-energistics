# Verlinkte Karte

![Ich fühle eine Verbindung](oredict:opencomputers:linkedCard)

Die verlinkte Karte ist eine spezialisierte und fortgeschrittene Version einer [Netzwerkkarte](lanCard.md). Gelinkte Karten treten nur im Paar auf und ermöglichen eine direkte Kommunikation zwischen den beiden Karten. Gelinkte Karten können über unbegrenzt weite Distanzen und über Dimensionen hinweg kommunizieren.
