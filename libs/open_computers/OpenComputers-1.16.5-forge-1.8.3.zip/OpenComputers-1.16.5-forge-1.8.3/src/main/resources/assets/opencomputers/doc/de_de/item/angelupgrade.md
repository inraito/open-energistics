# Engels-Upgrade

![Hallelujah.](oredict:opencomputers:angelUpgrade)

Dieses Upgrade ermöglicht es [Robotern](../block/robot.md) Blöcke mitten in die Luft zu platzieren.
