# Karten

![Können nicht gelesen werden.](oredict:opencomputers:materialCard)

Übliches Ausgangsmaterial für kartenförmige Komponenten in OpenComputers (wie [Grafikkarten](graphicsCard1.md), [Netzwerkkarten](lanCard.md) usw.)
