# Interweb

![A website is a place where there's cobweb.](oredict:opencomputers:materialInterweb)

The interweb is a basic component for all things related to long distance communication. It uses the strange mechanics of all things End to allow something along the lines of quantum communication. Used most notably in [internet cards](internetCard.md) and [linked cards](linkedCard.md).
