#REDIRECT chip1.md
