# Batterie-Upgrade

![Aus Metall angefertigt.](oredict:opencomputers:batteryUpgrade1)

Dieses Upgrade erhöht den internen Energiespeicher von Geräten wie [Robotern](../block/robot.md) und [Tablets](tablet.md). Sie können damit länger verwendet werden, bevor sie mit einem [Ladegerät](../block/charger.md) geladen werden müssen. Hochstufige Upgrades haben mehr Batteriekapazität.
