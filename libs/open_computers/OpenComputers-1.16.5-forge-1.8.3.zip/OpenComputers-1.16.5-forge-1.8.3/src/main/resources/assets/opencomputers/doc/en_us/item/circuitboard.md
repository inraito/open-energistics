# Circuit Board

![Needs more gold.](oredict:opencomputers:materialCircuitBoard)

Intermediate crafting item made from [raw circuit boards](rawCircuitBoard.md) and used to make [printed circuit boards](printedCircuitBoard.md).
