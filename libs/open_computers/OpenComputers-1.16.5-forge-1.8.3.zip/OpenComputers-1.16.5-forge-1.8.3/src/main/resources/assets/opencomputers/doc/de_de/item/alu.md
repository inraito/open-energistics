# Arithmetic Logic Unit

![Ich of logiks !](oredict:opencomputers:materialALU)

Wird für rechnende Komponenten wie [CPUs](cpu1.md) und [Grafikkarten](graphicsCard1.md) benötigt.
