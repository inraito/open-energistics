# Ziffernblock

![Prüfe es auf Fingerabdrücke.](oredict:opencomputers:materialNumPad)

Der Ziffernblock ist Teil einer jeden [Tastatur](../block/keyboard.md). Es erlaubt es, Zahlen einzugeben.
