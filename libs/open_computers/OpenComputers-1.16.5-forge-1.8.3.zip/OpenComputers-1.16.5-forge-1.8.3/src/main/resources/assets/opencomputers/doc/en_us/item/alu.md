# Arithmetic Logic Unit

![I can into logic!](oredict:opencomputers:materialALU)

Used for crafting components that perform calculations, such as [CPUs](cpu1.md) and [graphics cards](graphicsCard1.md).
