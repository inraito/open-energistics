# Raw Circuit Board

![Not sushi.](oredict:opencomputers:materialCircuitBoardRaw)

Intermediary crafting material, used for crafting [circuit boards](circuitBoard.md) (or [printed circuit boards](printedCircuitBoard.md), depending on the recipe set being used).
