# Komponentenschnittstelle

![Fährt nirgendwo hin](oredict:opencomputers:componentBus1)

Eine Komponentenschnittstelle ist ein [Server](server1.md)spezifisches Upgrade das es dem Server erlaubt, mit mehr Komponenten auf einmal zu kommunizieren ohne sich abzuschalten. Wie bei [CPUs](cpu1.md) auch ermöglichen höhere Stufen mehr Komponenten und höhere Stufen für Server ermöglichen mehr Slots für Komponentenschnittstellen.

Das Komponentenlimit ist wie folgt
- Stufe 1: 8 Komponenten.
- Stufe 2: 12 Komponenten.
- Stufe 3: 16 Komponenten. 
