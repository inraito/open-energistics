# Speicherplatte

![World. RIP Terry Pratchett.](oredict:opencomputers:materialDisk)

Grundlegende Komponente, die zum Bau von Speichermedien wie [Disketten](floppy.md) und [Festplatten](hdd1.md) benötigt wird.
