# Crafting-Upgrade

![Kräftig.](oredict:opencomputers:craftingUpgrade)

Das Crafting-Upgrade erlaubt [Robotern](../block/robot.md) jede Art von Rezepten zu fertigen. Dabei werden Items aus dem [Inventar](../item/inventoryUpgrade.md) verwendet. Das 3x3-Netz im Inventar des Roboters wird als Werkbank verwendet. Items müssen entsprechend dem Rezept angeordnet sein. Ergebnisse werden im gewählten Slot im Inventar oder im nächsten freien Slot abgelegt, oder in die Welt geworfen, wenn kein Platz mehr übrig ist.
