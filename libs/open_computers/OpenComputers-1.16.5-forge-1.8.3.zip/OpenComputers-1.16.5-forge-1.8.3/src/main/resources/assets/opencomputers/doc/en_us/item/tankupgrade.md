# Tank Upgrade

![Suck it.](oredict:opencomputers:tankUpgrade)

The tank upgrade allows devices to store fluids. Each tank can only hold a single type of fluid, and provides a volume of 16 buckets (16000mB). [Robots](../block/robot.md) and [drones](drone.md) can drain liquids from the world and from other fluid tanks, and can fill the fluids back into fluid tanks, and when supported by the fluid, place them back into the world. There is no limit to the number of tanks that can be installed in a device.
