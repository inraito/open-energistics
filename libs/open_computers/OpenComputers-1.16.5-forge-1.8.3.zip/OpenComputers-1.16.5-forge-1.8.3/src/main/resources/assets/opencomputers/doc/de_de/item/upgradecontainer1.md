# Upgrade-Container

![Kann Upgrade haben.](oredict:opencomputers:upgradeContainer1)

Der Upgrade-Container ist ein Container-Upgrade für [Roboter](../block/robot.md). Es stellt einen Slot im Roboter zur Verfügung, in dem normale Upgrades platziert werden können. Die höchste Stufe das ein Upgrade haben darf gleicht der Stufe des Containers. Im Gegensatz zu normalen Upgrades ist die Komplexität des Containers doppelt so groß wie die Stufe. Für mehr Informationen über Komplexität siehe [Roboter](../block/robot.md) und [Elektronik-Werkbank](../block/assembler.md).
