# Card

![Can't be read.](oredict:opencomputers:materialCard)

Common crafting material for card components in OpenComputers (such as [graphics cards](graphicsCard1.md), [network cards](lanCard.md), etc).
