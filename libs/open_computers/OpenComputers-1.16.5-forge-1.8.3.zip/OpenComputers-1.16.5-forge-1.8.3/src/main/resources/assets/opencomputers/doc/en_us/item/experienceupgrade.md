# Experience Upgrade

![This makes no sense, but it's cool.](oredict:opencomputers:experienceUpgrade)

The experience upgrade is a very special upgrade, as it allows [robots](../block/robot.md) and [drones](drone.md) to collect experience by performing various actions, such as digging up ores and killing entities. A single upgrade can store up to 30 levels, providing passive bonuses with each level, including faster harvest speeds and increased energy buffer capacity.

[Robots](../block/robot.md) at level ten and above will get a golden tint, [robots](../block/robot.md) at level twenty and above will get a diamond tint.

The actual experience is stored inside the upgrade, meaning if the upgrade is transferred to another device, so is the experience.
