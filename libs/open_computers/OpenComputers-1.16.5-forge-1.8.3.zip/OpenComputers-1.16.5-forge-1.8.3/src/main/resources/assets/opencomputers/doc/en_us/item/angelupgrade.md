# Angel Upgrade

![Hallelujah.](oredict:opencomputers:angelUpgrade)

This upgrade allows [robots](../block/robot.md) to place blocks in thin air, without a reference block.