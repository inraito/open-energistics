# Block of Chamelium

![So... blank.](oredict:opencomputers:chameliumBlock)

A few pieces of [chamelium](../item/chamelium.md) can be combined to provide a monochrome block for decorative purposes. Chamelium blocks can also be dyed with any of the 16 Minecraft colors. 

Using the Chamelium block as a texture for [3D prints](print.md) provides a clean white surface for applying tints. 
