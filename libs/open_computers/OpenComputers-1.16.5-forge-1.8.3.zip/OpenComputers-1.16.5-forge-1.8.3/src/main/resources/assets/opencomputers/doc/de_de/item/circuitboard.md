# Leiterplatte

![Braucht mehr Gold.](oredict:opencomputers:materialCircuitBoard)

Zwischenitem das beim Herstellen von [bedruckten Leiterplatten](printedCircuitBoard.md) aus [rohen Leiterplatten](rawCircuitBoard.md) entsteht.
