# Tastatur

![QWERTY](oredict:opencomputers:keyboard)

Eine Tastatur wird benötigt um Text auf [Bildschirme](screen1.md) zu schreiben, egal ob in der Welt platziert oder in Geräte eingebaut (wie bei [Robotern](robot.md) oder [Tablets](../item/tablet.md)).

Damit eine Tastatur mit einem [Bildschirm](screen1.md) in der Welt funktioniert, muss sie neben dem Bildschirm und in Richtung des Bildschirms oder direkt auf dem Bildschirm aufgestellt werden. Ob die Tastatur funktioniert kann festgestellt werden, wenn beim Rechtsklick auf die Tastatur die GUI des Bildschirms geöffnet wird.
